| Type | Name | Image/Proc | State | Health | Ports | Networks | Mounts | Notes |
| ---- | ---- | ---------- | ----- | ------ | ----- | -------- | ------ | ----- |
| container | graphiti | marka-graphiti | running | healthy | 7878->7878/tcp,7878->7878/tcp | marka_marka_net |  | restart=unless-stopped |
| container | graphiti-neo4j | neo4j:5.11 | running | healthy | 7474->7474/tcp,7474->7474/tcp,7687->7687/tcp,7687->7687/tcp | marka_marka_net | /var/lib/docker/volumes/296cf9810de9842cab50627d0a565261b409fadccb959065c2432a630cd8efcf/_data:/logs,/var/lib/docker/volumes/marka_graphiti-neo4j-data/_data:/data | restart=unless-stopped |
| container | marka-redis | redis:7-alpine | running | healthy | 6379->6379/tcp | marka_marka_net | /var/lib/docker/volumes/marka_redis_data/_data:/data | restart=unless-stopped |
| container | mark-mcp | marka-mark-mcp | running | healthy | 8788->8788/tcp,8788->8788/tcp | marka_marka_net | /home/sergey/marka/mark_mcp:/app,/home/sergey/marka:/srv/mark,/home/sergey/marka/logs:/var/log/mark,/home/sergey/marka/data:/data/mark | restart=unless-stopped |
| container | bot | marka-bot | running |  |  | marka_marka_net | /home/sergey/marka/langchain_api:/app/langchain_api | restart=always |
| container | sandbox | python:3.10-slim | running |  |  | marka_marka_net | /var/lib/docker/volumes/marka_dev_sandbox/_data:/workspace | restart=no |
| container | app | marka-app | running | healthy | 8000->8000/tcp,8000->8000/tcp | marka_marka_net | /home/sergey/marka/langchain_api/scripts:/app/scripts,/var/lib/docker/volumes/marka_dev_sandbox/_data:/sandbox,/home/sergey/marka/langchain_api:/app | restart=always |
