## Хост
- ОС: Ubuntu 22.04.5 LTS (5.15.0-153-generic)
- Время работы: 13d 14h 48m TZ: UTC
- Диски: [('/', 75)]

## Контейнеры
- graphiti: marka-graphiti: state=running health=healthy
- graphiti-neo4j: neo4j:5.11:5.11 state=running health=healthy
- marka-redis: redis:7-alpine:7-alpine state=running health=healthy
- mark-mcp: marka-mark-mcp: state=running health=healthy
- bot: marka-bot: state=running health=
- sandbox: python:3.10-slim:3.10-slim state=running health=
- app: marka-app: state=running health=healthy

## Репозитории
- marka @ /home/sergey/marka [main] dirty=True

## Сеть & Прокси
- HTTP_PROXY: 
- HTTPS_PROXY: 
- NO_PROXY: 
