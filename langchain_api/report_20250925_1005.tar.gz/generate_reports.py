import os, sys, json, re, glob, socket, platform, time, subprocess
from datetime import datetime

REPORT_DIR = os.environ.get('REPORT_DIR', '/home/sergey/mark_reports/2025-09-25_1001')

os.makedirs(REPORT_DIR, exist_ok=True)

TECH = os.path.join(REPORT_DIR, 'TECH_JOURNAL.md')

def log(msg: str):
    with open(TECH, 'a', encoding='utf-8') as f:
        f.write(f"- {datetime.now().isoformat()}: {msg}\n")

# Redaction helper

def redact_value(value: str) -> str:
    if value is None:
        return "(len=0)"
    s = str(value)
    n = len(s)
    if n <= 5:
        return f"{s[:1]}***{s[-1:]} (len={n})"
    return f"{s[:3]}***{s[-2:]} (len={n})"

# Collect host info

def get_host_info():
    host = {}
    host['hostname'] = socket.gethostname()
    host['os'] = platform.system()
    # distro
    distro = ''
    try:
        with open('/etc/os-release') as f:
            data = dict(line.strip().split('=', 1) for line in f if '=' in line)
            distro = data.get('PRETTY_NAME', '').strip('"')
    except Exception:
        distro = platform.platform()
    host['distro'] = distro
    host['kernel'] = platform.release()
    # CPU
    cpu_model = ''
    try:
        with open('/proc/cpuinfo') as f:
            for line in f:
                if 'model name' in line:
                    cpu_model = line.split(':',1)[1].strip()
                    break
    except Exception:
        pass
    host['cpu'] = { 'model': cpu_model, 'cores': os.cpu_count() or 0 }
    # RAM
    ram_mb = 0
    try:
        with open('/proc/meminfo') as f:
            for line in f:
                if line.startswith('MemTotal:'):
                    parts = line.split()
                    kB = int(parts[1])
                    ram_mb = kB // 1024
                    break
    except Exception:
        pass
    host['ram_mb'] = ram_mb
    # uptime
    uptime = ''
    try:
        with open('/proc/uptime') as f:
            sec = float(f.read().split()[0])
            days = int(sec // 86400)
            sec -= days*86400
            hrs = int(sec // 3600)
            sec -= hrs*3600
            mins = int(sec // 60)
            uptime = f"{days}d {hrs}h {mins}m"
    except Exception:
        pass
    host['uptime'] = uptime
    # timezone
    try:
        tz = time.tzname[0]
    except Exception:
        tz = ''
    host['timezone'] = tz
    # IPs
    local_ips = []
    try:
        out = subprocess.check_output(['ip','-o','-4','addr','show'], text=True)
        for line in out.splitlines():
            m = re.search(r'inet\s+(\d+\.\d+\.\d+\.\d+)', line)
            if m:
                ip = m.group(1)
                if ip not in local_ips:
                    local_ips.append(ip)
    except Exception:
        pass
    host['ips'] = { 'local': local_ips, 'public': '' }
    # disks
    disks = []
    try:
        out = subprocess.check_output(['df','-BG','-T'], text=True)
        for line in out.splitlines()[1:]:
            parts = line.split()
            if len(parts) >= 7:
                mount = parts[6]
                size_gb = int(parts[2].rstrip('G')) if parts[2].endswith('G') else 0
                used_gb = int(parts[3].rstrip('G')) if parts[3].endswith('G') else 0
                pct = int(parts[5].rstrip('%')) if parts[5].endswith('%') else 0
                if mount in ['/', '/home', '/var', '/opt']:
                    disks.append({ 'mount': mount, 'size_gb': size_gb, 'used_gb': used_gb, 'pct': pct })
    except Exception:
        pass
    host['disks'] = disks
    return host

# Network & proxy

def get_network_info():
    network = {}
    # listening
    listening = []
    try:
        out = subprocess.check_output(['ss','-tulpn'], text=True, stderr=subprocess.DEVNULL)
        for line in out.splitlines():
            if 'LISTEN' in line and ('tcp' in line or 'udp' in line):
                proto = 'tcp' if 'tcp' in line else ('udp' if 'udp' in line else '')
                # extract port
                m = re.search(r':(\d+)\s', line)
                port = int(m.group(1)) if m else 0
                proc = ''
                m2 = re.search(r'users:\(\("([^"]+)"', line)
                if m2:
                    proc = m2.group(1)
                listening.append({ 'proto': proto, 'port': port, 'process': proc, 'user': '' })
    except Exception as e:
        log(f"ss failed: {e}")
    network['listening'] = listening
    # firewall
    ufw_state = ''
    try:
        out = subprocess.check_output(['ufw','status'], text=True, stderr=subprocess.STDOUT)
        ufw_state = out.strip().splitlines()[0]
    except Exception as e:
        ufw_state = 'unavailable (need root or ufw not installed)'
    iptables_count = 0
    try:
        out = subprocess.check_output(['iptables','-S'], text=True, stderr=subprocess.STDOUT)
        iptables_count = len(out.splitlines())
    except Exception:
        pass
    network['firewall'] = { 'ufw': ufw_state, 'iptables_rules_count': iptables_count }
    # dns
    resolv = ''
    nameservers = []
    try:
        with open('/etc/resolv.conf') as f:
            resolv = f.read()
        for line in resolv.splitlines():
            if line.strip().startswith('nameserver'):
                ns = line.split()[1]
                nameservers.append(ns)
    except Exception:
        pass
    network['dns'] = { 'resolv_conf': resolv, 'nameservers': nameservers }
    # proxy env
    env = os.environ
    http_proxy = env.get('HTTP_PROXY') or env.get('http_proxy') or ''
    https_proxy = env.get('HTTPS_PROXY') or env.get('https_proxy') or ''
    no_proxy = env.get('NO_PROXY') or env.get('no_proxy') or ''
    network['proxy'] = { 'HTTP_PROXY': http_proxy, 'HTTPS_PROXY': https_proxy, 'NO_PROXY': [x.strip() for x in no_proxy.split(',') if x.strip()] }
    return network

# Docker info from existing inspect files (fallback to docker if needed)

def parse_container_inspect(path):
    with open(path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    # docker inspect returns an array normally; our dump used '{{json .}}' -> single object
    if isinstance(data, list) and data:
        data = data[0]
    name = data.get('Name','').lstrip('/')
    image_full = data.get('Config',{}).get('Image','')
    tag = ''
    if ':' in image_full:
        tag = image_full.split(':')[-1]
    state = data.get('State',{}).get('Status','')
    health = data.get('State',{}).get('Health',{}).get('Status','') if data.get('State',{}).get('Health') else ''
    # ports
    ports_list = []
    ports = data.get('NetworkSettings',{}).get('Ports',{}) or {}
    for cport, bindings in ports.items():
        # cport like '8000/tcp'
        try:
            cnum, proto = cport.split('/')
            cnum = int(cnum)
        except Exception:
            cnum, proto = 0, 'tcp'
        if not bindings:
            continue
        for b in bindings:
            host_port = int(b.get('HostPort','0')) if b.get('HostPort') else 0
            ports_list.append({ 'host': host_port, 'container': cnum, 'proto': proto })
    # networks
    networks = list((data.get('NetworkSettings',{}).get('Networks') or {}).keys())
    # mounts
    mounts = []
    for m in data.get('Mounts',[]) or []:
        src = m.get('Source',''); dst = m.get('Destination','')
        mounts.append(f"{src}:{dst}")
    restart = data.get('HostConfig',{}).get('RestartPolicy',{}).get('Name','')
    # env
    env_list = []
    for ev in data.get('Config',{}).get('Env') or []:
        if '=' in ev:
            k,v = ev.split('=',1)
            env_list.append({ 'key': k, 'value': redact_value(v) })
    return {
        'name': name,
        'image': image_full,
        'tag': tag,
        'state': state,
        'health': health,
        'ports': ports_list,
        'networks': networks,
        'mounts': mounts,
        'restart': restart,
        'env_redacted': env_list,
    }


def get_docker_info():
    dk = { 'version': '', 'compose_version': '', 'containers': [], 'networks': [], 'volumes': [] }
    # versions
    try:
        out = subprocess.check_output(['docker','version','--format','{{json .}}'], text=True)
        dk['version'] = json.loads(out).get('Server',{}).get('Version','')
    except Exception as e:
        log(f"docker version unavailable: {e}")
    try:
        out = subprocess.check_output(['docker','compose','version'], text=True)
        dk['compose_version'] = out.strip()
    except Exception:
        try:
            out = subprocess.check_output(['docker-compose','version'], text=True)
            dk['compose_version'] = out.strip()
        except Exception as e:
            dk['compose_version'] = ''
            log(f"compose version unavailable: {e}")
    # containers from inspect files
    for path in glob.glob(os.path.join(REPORT_DIR, 'inspect_*.json')):
        try:
            dk['containers'].append(parse_container_inspect(path))
        except Exception as e:
            log(f"failed to parse {path}: {e}")
    # networks
    nets = []
    for path in glob.glob(os.path.join(REPORT_DIR, 'docker_network_*.json')):
        try:
            data = json.load(open(path))
            if isinstance(data, list) and data:
                data = data[0]
            nets.append(data.get('Name',''))
        except Exception:
            pass
    dk['networks'] = [n for n in nets if n]
    # volumes
    try:
        out = subprocess.check_output(['docker','volume','ls','-q'], text=True)
        dk['volumes'] = [v for v in out.splitlines() if v.strip()]
    except Exception as e:
        log(f"docker volume ls unavailable: {e}")
    return dk

# Git repos: include current repo and any from phase4 scan

def redact_remote(url: str) -> str:
    # Basic redaction if credentials embedded
    if not url:
        return ''
    m = re.match(r'([^:]+://)([^@]+)@(.+)', url)
    if m:
        return m.group(1) + '***@' + m.group(3)
    return url


def get_repo_info(paths):
    repos = []
    for p in paths:
        if not os.path.isdir(p):
            continue
        try:
            top = subprocess.check_output(['git','-C',p,'rev-parse','--show-toplevel'], text=True).strip()
        except Exception:
            continue
        name = os.path.basename(top.rstrip('/'))
        try:
            branch = subprocess.check_output(['git','-C',p,'rev-parse','--abbrev-ref','HEAD'], text=True).strip()
        except Exception:
            branch = ''
        try:
            dirty = bool(subprocess.check_output(['git','-C',p,'status','--porcelain'], text=True).strip())
        except Exception:
            dirty = False
        try:
            remotes = subprocess.check_output(['git','-C',p,'remote','-v'], text=True)
            remote_url = ''
            for line in remotes.splitlines():
                if '(fetch)' in line and '\t' in line:
                    remote_url = line.split('\t')[1].split()[0]
                    break
        except Exception:
            remote_url = ''
        try:
            last = subprocess.check_output(['git','-C',p,'log','-1','--pretty=format:%H|%ad|%an|%s','--date=iso'], text=True)
            sha,date,author,msg = last.split('|',3)
            last_commit = { 'sha': sha, 'date': date, 'author': author, 'msg': msg }
        except Exception:
            last_commit = { 'sha':'', 'date':'', 'author':'', 'msg':'' }
        repos.append({
            'path': top,
            'name': name,
            'branch': branch,
            'dirty': dirty,
            'remote_url_redacted': redact_remote(remote_url),
            'last_commit': last_commit
        })
    return repos

# Apps detection using port probes file

def get_api_discovery():
    arr = []
    probe_file = os.path.join(REPORT_DIR, 'phase5_api_probe.txt')
    if not os.path.exists(probe_file):
        return arr
    bases = {}
    with open(probe_file,'r',encoding='utf-8') as f:
        for line in f:
            m = re.search(r'PORT\s+(\d+)\s+/([^\s]+)\s+(\d+)', line)
            if not m:
                continue
            port, path, code = m.group(1), m.group(2), int(m.group(3))
            base = f"http://127.0.0.1:{port}"
            info = bases.setdefault(base, { 'openapi': False, 'docs': False, 'sample_endpoints': [] })
            if path == 'openapi' and code == 200:
                info['openapi'] = True
            if path == 'docs' and code == 200:
                info['docs'] = True
            info['sample_endpoints'].append({ 'method':'GET', 'path': f"/{path if path!='openapi' else 'openapi.json'}", 'status': code })
    for base, meta in bases.items():
        arr.append({ 'base': base, 'openapi': meta['openapi'], 'docs': meta['docs'], 'sample_endpoints': meta['sample_endpoints'] })
    return arr

# Memory services detection via docker container names/images

def get_memory_info(containers):
    mem = {
        'redis': { 'present': False, 'version': '', 'used_mb': 0, 'keys': 0, 'dbs': [], 'top_prefixes': [] },
        'graphiti': { 'present': False, 'version': '', 'endpoint': '', 'notes': '' },
        'neo4j': { 'present': False, 'version': '', 'labels_counts': [], 'bolt_port': 0 },
    }
    # Detect presence by image/name
    for c in containers:
        name = c.get('name','').lower()
        image = (c.get('image','') or '').lower()
        if 'redis' in name or 'redis' in image:
            mem['redis']['present'] = True
            # Try to get version via docker exec (optional)
            try:
                out = subprocess.check_output(['docker','exec',name,'redis-cli','INFO','server'], text=True, stderr=subprocess.STDOUT, timeout=2)
                for line in out.splitlines():
                    if line.startswith('redis_version:'):
                        mem['redis']['version'] = line.split(':',1)[1].strip()
                        break
                out2 = subprocess.check_output(['docker','exec',name,'redis-cli','INFO','memory'], text=True, stderr=subprocess.STDOUT, timeout=2)
                for line in out2.splitlines():
                    if line.startswith('used_memory_human:'):
                        val = line.split(':',1)[1].strip()
                        if val.endswith('M'):
                            mem['redis']['used_mb'] = float(val[:-1])
                        break
                # DBSIZE
                try:
                    out3 = subprocess.check_output(['docker','exec',name,'redis-cli','DBSIZE'], text=True, stderr=subprocess.STDOUT, timeout=2)
                    mem['redis']['keys'] = int(out3.strip())
                except Exception:
                    pass
            except Exception as e:
                mem['redis']['notes'] = 'metrics not accessible'
        if 'neo4j' in name or 'neo4j' in image:
            mem['neo4j']['present'] = True
        if 'graphiti' in name or 'graphiti' in image:
            mem['graphiti']['present'] = True
    return mem

# Apps section (basic heuristics)

def get_apps_section(api_discovery):
    apps = {
        'agents_sdk': { 'present': False, 'version': '', 'process': '', 'ports': [], 'openapi': False },
        'fastapi': { 'present': False, 'endpoints': [] },
        'nginx': { 'present': False, 'sites': [] },
        'telegram_bot': { 'present': False, 'webhook_url': '', 'notes': 'tokens redacted' },
    }
    # If any base had openapi/docs true, consider fastapi present
    for a in api_discovery:
        if a.get('openapi') or a.get('docs'):
            apps['fastapi']['present'] = True
            apps['fastapi']['endpoints'] = [e for e in a.get('sample_endpoints', [])]
    return apps

# Risks (basic)

def compute_risks(host, network, docker_info):
    risks = []
    # Disk usage > 85%
    for d in host.get('disks', []):
        if d.get('pct',0) >= 85:
            risks.append({ 'title': f"Высокая заполненность диска {d['mount']}", 'evidence': f"{d['pct']}%", 'severity':'med', 'hint':'Очистить кеши/логи, увеличить диск' })
    # Unhealthy containers
    for c in docker_info.get('containers', []):
        if c.get('health') and c.get('health') != 'healthy':
            risks.append({ 'title': f"Контейнер {c['name']} нездоров", 'evidence': c.get('health'), 'severity':'high', 'hint':'Проверить логи контейнера' })
    # NO_PROXY absent
    if not network.get('proxy', {}).get('NO_PROXY'):
        risks.append({ 'title': 'NO_PROXY не задан', 'evidence': 'пусто', 'severity':'med', 'hint':'Добавить docker-сервисы, 127.0.0.1, localhost' })
    return risks

# Unknowns

def default_unknowns():
    return [
        { 'question': 'Есть ли резервные копии БД/файлов?', 'where_to_look': '/etc/cron*, /var/backups, контейнеры backup' },
        { 'question': 'Используется ли внешний прокси для исходящих запросов?', 'where_to_look': '/etc/environment, переменные окружения сервисов' },
    ]


def main():
    log('Начало генерации SYSTEM_STATUS.json')
    host = get_host_info()
    network = get_network_info()
    docker_info = get_docker_info()
    repos = get_repo_info(['/home/sergey/marka'])
    api_discovery = get_api_discovery()
    memory = get_memory_info(docker_info.get('containers', []))
    apps = get_apps_section(api_discovery)
    risks = compute_risks(host, network, docker_info)
    unknowns = default_unknowns()

    system_status = {
        'host': host,
        'network': network,
        'docker': docker_info,
        'repos': repos,
        'apps': apps,
        'memory': memory,
        'api_discovery': api_discovery,
        'cron_backups': { 'cron': [], 'fstrim': False, 'snapshots': [] },
        'risks': risks,
        'unknowns': unknowns,
        'generated_at': datetime.now().isoformat()
    }

    with open(os.path.join(REPORT_DIR, 'SYSTEM_STATUS.json'), 'w', encoding='utf-8') as f:
        json.dump(system_status, f, ensure_ascii=False, indent=2)
    log('Сформирован SYSTEM_STATUS.json')

    # PROJECT_MAP.md (brief)
    pm = os.path.join(REPORT_DIR, 'PROJECT_MAP.md')
    with open(pm, 'w', encoding='utf-8') as f:
        f.write('## Хост\n')
        f.write(f"- ОС: {host.get('distro')} ({host.get('kernel')})\n")
        f.write(f"- Время работы: {host.get('uptime')} TZ: {host.get('timezone')}\n")
        f.write(f"- Диски: {[ (d['mount'], d['pct']) for d in host.get('disks',[]) ]}\n\n")
        f.write('## Контейнеры\n')
        for c in docker_info.get('containers', []):
            f.write(f"- {c['name']}: {c['image']}:{c.get('tag','')} state={c['state']} health={c['health']}\n")
        f.write('\n## Репозитории\n')
        for r in repos:
            f.write(f"- {r['name']} @ {r['path']} [{r['branch']}] dirty={r['dirty']}\n")
        f.write('\n## Сеть & Прокси\n')
        pr = network.get('proxy', {})
        f.write(f"- HTTP_PROXY: {redact_value(pr.get('HTTP_PROXY','')) if pr.get('HTTP_PROXY') else ''}\n")
        f.write(f"- HTTPS_PROXY: {redact_value(pr.get('HTTPS_PROXY','')) if pr.get('HTTPS_PROXY') else ''}\n")
        f.write(f"- NO_PROXY: {', '.join(pr.get('NO_PROXY', []))}\n")
    log('Сформирован PROJECT_MAP.md')

    # SERVICES.md (table)
    sm = os.path.join(REPORT_DIR, 'SERVICES.md')
    with open(sm, 'w', encoding='utf-8') as f:
        f.write('| Type | Name | Image/Proc | State | Health | Ports | Networks | Mounts | Notes |\n')
        f.write('| ---- | ---- | ---------- | ----- | ------ | ----- | -------- | ------ | ----- |\n')
        for c in docker_info.get('containers', []):
            ports = ','.join([f"{p['host']}->{p['container']}/{p['proto']}" for p in c.get('ports',[])])
            nets = ','.join(c.get('networks',[]))
            mnts = ','.join(c.get('mounts',[]))
            f.write(f"| container | {c['name']} | {c['image']} | {c['state']} | {c['health']} | {ports} | {nets} | {mnts} | restart={c.get('restart','')} |\n")
    log('Сформирован SERVICES.md')

    # NETWORK_PROXY.md
    np = os.path.join(REPORT_DIR, 'NETWORK_PROXY.md')
    with open(np, 'w', encoding='utf-8') as f:
        f.write('### Переменные прокси\n')
        pr = network.get('proxy', {})
        def red(s):
            return redact_value(s) if s else ''
        f.write(f"- HTTP_PROXY: {red(pr.get('HTTP_PROXY'))}\n")
        f.write(f"- HTTPS_PROXY: {red(pr.get('HTTPS_PROXY'))}\n")
        f.write(f"- NO_PROXY: {', '.join(pr.get('NO_PROXY', []))}\n\n")
        f.write('### resolv.conf\n')
        f.write('````\n')
        f.write(network.get('dns', {}).get('resolv_conf',''))
        f.write('\n````\n')
    log('Сформирован NETWORK_PROXY.md')

    # MEMORY.md
    mm = os.path.join(REPORT_DIR, 'MEMORY.md')
    with open(mm, 'w', encoding='utf-8') as f:
        r = memory['redis']; g = memory['graphiti']; n = memory['neo4j']
        f.write(f"- Redis present: {r['present']}, version: {r.get('version','')}\n")
        f.write(f"- Graphiti present: {g['present']}\n")
        f.write(f"- Neo4j present: {n['present']}\n")
    log('Сформирован MEMORY.md')

    # APPS_ENDPOINTS.md
    ae = os.path.join(REPORT_DIR, 'APPS_ENDPOINTS.md')
    with open(ae, 'w', encoding='utf-8') as f:
        for a in get_api_discovery():
            f.write(f"- Base: {a['base']} openapi={a['openapi']} docs={a['docs']}\n")
            for e in a['sample_endpoints']:
                f.write(f"  - {e['method']} {e['path']} -> {e['status']}\n")
    log('Сформирован APPS_ENDPOINTS.md')

    # ARCHITECTURE.mmd (basic)
    arch = os.path.join(REPORT_DIR, 'ARCHITECTURE.mmd')
    with open(arch, 'w', encoding='utf-8') as f:
        f.write('flowchart LR\n')
        f.write('  user([User])-->api(API)\n')
        # memory nodes if present
        if memory['redis']['present']:
            f.write('  api-->redis[(Redis)]\n')
        if memory['neo4j']['present']:
            f.write('  api-->neo4j[(Neo4j)]\n')
        if memory['graphiti']['present']:
            f.write('  api-->graphiti[(Graphiti)]\n')
    log('Сформирован ARCHITECTURE.mmd')

    # REPORT_SUMMARY.md
    summ = os.path.join(REPORT_DIR, 'REPORT_SUMMARY.md')
    with open(summ, 'w', encoding='utf-8') as f:
        f.write('### Краткая выжимка\n')
        f.write(f"- Хост: {host.get('distro')} {host.get('kernel')}\n")
        f.write(f"- Контейнеров: {len(docker_info.get('containers', []))}\n")
        f.write(f"- Открытых API: {len(get_api_discovery())}\n\n")
        f.write('Топ-риски:\n')
        for r in risks[:3]:
            f.write(f"- {r['title']}: {r['evidence']}\n")
    log('Сформирован REPORT_SUMMARY.md')

    # mark_memory_update.json
    mmu = {
        'project': 'Марк',
        'snapshot_time': datetime.now().isoformat(),
        'core_facts': [],
        'versions': [
            {'component':'agents_sdk','version':''},
            {'component':'redis','version': memory['redis'].get('version','')},
            {'component':'graphiti','version':''},
            {'component':'neo4j','version':''},
        ],
        'endpoints': [],
        'ports': [],
        'paths': [ {'name':'repo_root','path':'/home/sergey/marka'}, {'name':'reports_dir','path': REPORT_DIR } ],
        'risks': risks,
        'unknowns': default_unknowns()
    }
    for a in get_api_discovery():
        mmu['endpoints'].append({ 'service':'api', 'base': a['base'], 'paths': [e['path'] for e in a['sample_endpoints'][:3]] })
        try:
            port = int(a['base'].split(':')[-1])
            mmu['ports'].append({'port': port, 'service':'api'})
        except Exception:
            pass
    with open(os.path.join(REPORT_DIR, 'mark_memory_update.json'), 'w', encoding='utf-8') as f:
        json.dump(mmu, f, ensure_ascii=False, indent=2)
    log('Сформирован mark_memory_update.json')

if __name__ == '__main__':
    main()
