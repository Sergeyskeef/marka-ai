### Graphiti (на Neo4j) — лучшие практики
- SLA/таймауты клиента: использовать http-клиент с таймаутами (connect/read ≤ 5–15s), ретраи с экспоненциальной паузой и джиттером; отдельные таймауты на запись/чтение.
- Схема/миграции в Neo4j: хранить bootstrap-скрипт индексов/ограничений (Cypher), исполнять при развертывании; документировать версионирование.
- Temporal edges: фиксировать стратегию версионирования/валидности (from_ts/to_ts) и индексацию ключевых узлов/отношений.
- MCP-интеграция: для IDE/агентов поддерживать Graphiti MCP Server, фиксировать порты/NO_PROXY.
- Безопасность: закрыть браузерный порт Neo4j от внешнего доступа в DEV, использовать сильные пароли, хранить секреты вне образов.

Источники:
- Neo4j blog: Graphiti knowledge graph memory [neo4j.com](`https://neo4j.com/blog/developer/graphiti-knowledge-graph-memory/`)
- GitHub getzep/graphiti [github.com](`https://github.com/getzep/graphiti`)
- Graphiti MCP Server docs [getzep.com](`https://help.getzep.com/graphiti/getting-started/mcp-server`)

### Redis — лучшие практики
- Security/ACL: использовать ACL вместо одного requirepass; избегать дефолтных паролей; protected-mode yes; ограничить bind/публикацию портов.
- Память: задать maxmemory и политику эвикции, для кэша — allkeys-lru/volatile-ttl (по сценарию); TTL для кэширующих ключей.
- Надежность: выбирать AOF или RDB по требованиям (часто — AOF everysec); мониторить задержки и пропуски репликации (если есть).
Источники:
- Redis Security [redis.io](`https://redis.io/docs/latest/operate/oss_and_stack/management/security/`)
- Redis ACL [redis.io](`https://redis.io/docs/latest/operate/oss_and_stack/management/security/acl/`)
- Eviction policies [redis.io](`https://redis.io/docs/latest/develop/reference/eviction/`)

### Neo4j 5.x — лучшие практики
- Экспозиция: закрыть :7474 наружу в DEV, Bolt :7687 не публиковать вне хоста/прокси.
- Пароли: обязательны сильные; хранить в секретах, не в образе.
- Бэкапы: CE — dump/load через neo4j-admin; EE — online backup; хранить оффсайтово; документировать процедуру восстановления.
- Индексы/ограничения: заранее создавать для горячих связей/узлов.
Источники:
- Backup/restore [neo4j.com](`https://neo4j.com/docs/operations-manual/current/backup-restore/`)
- Editions overview [neo4j.com](`https://neo4j.com/docs/operations-manual/current/introduction/`)
