### TEST PLAN — MEMORY (Graphiti + Neo4j + Redis)

1) Redis
- Проверить конфиг: `docker exec marka-redis redis-cli CONFIG GET maxmemory-policy` → ожидается allkeys-lru (или выбранная)
- TTL: создать тестовые ключи c TTL и убедиться, что истекают.
- PING/AUTH: `docker exec marka-redis redis-cli -a $REDIS_PASSWORD PING` → PONG

2) Neo4j
- Dump/Load (на тестовой инстанции): `docker exec graphiti-neo4j neo4j-admin database dump neo4j --to-path=/data/dumps`
- Проверить индексы/констрейнты из bootstrap Cypher.

3) Graphiti
- `curl http://127.0.0.1:7878/health` → 200 OK
- Сценарий: добавить память и найти её (через API/адаптер).

4) /health/extended (после внедрения)
- Проверка subchecks: graphiti_ok, neo4j_ok, redis_ok, proxy_ok → все True

Критерии готовности: все проверки зелёные; параметры безопасности применены; экспозиция портов ограничена.
