"""
Tests for graphiti package
"""