"""
Tests for metrics package
"""